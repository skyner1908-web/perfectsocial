// server.cjs

require("dotenv").config();
const express = require("express");
const cors = require("cors");
const OpenAI = require("openai");

const app = express();
const PORT = process.env.PORT || 3000;

// ====== CHECK CHIAVE OPENAI ======
if (!process.env.OPENAI_API_KEY) {
  console.error("❌ ERRORE: manca OPENAI_API_KEY nel file .env");
  console.error("Aggiungi una riga tipo: OPENAI_API_KEY=la_tua_chiave_qui");
  process.exit(1);
}

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// cors + json con limite alto per le immagini base64
app.use(cors());
app.use(
  express.json({
    limit: "20mb",
  })
);

/**
 * POST /generate
 * Body:
 *  {
 *    messages: [
 *      { role: "system", content: string },
 *      { role: "user" | "assistant", content: string, imageUrl?: string }
 *    ],
 *    turbo?: boolean
 *  }
 */
app.post("/generate", async (req, res) => {
  try {
    const { messages, turbo } = req.body || {};

    if (!Array.isArray(messages) || messages.length === 0) {
      return res
        .status(400)
        .json({ error: "Campo 'messages' mancante o vuoto." });
    }

    // mappo i messaggi nel formato della Responses API
    const input = messages.map((msg) => {
      // messaggio utente con immagine -> vision
      if (msg.role === "user" && msg.imageUrl) {
        const text =
          msg.content && msg.content.trim().length > 0
            ? msg.content
            : "Analizza questa immagine e dammi idee per i contenuti social, copy e strategia.";

        return {
          role: "user",
          content: [
            { type: "input_text", text },
            {
              type: "input_image",
              image_url: msg.imageUrl, // è già un data URL base64
            },
          ],
        };
      }

      // tutti gli altri messaggi (system / assistant / user senza immagine)
      return {
        role: msg.role,
        content: msg.content,
      };
    });

    const model = turbo ? "gpt-4.1" : "gpt-4.1-mini";

    const response = await client.responses.create({
      model,
      input,
    });

    return res.json({
      result: response.output_text,
    });
  } catch (error) {
    console.error("Errore /generate:", error);

    if (error.response && error.response.data) {
      return res.status(500).json({
        error:
          error.response.data.error?.message ||
          "Errore durante la chiamata a OpenAI.",
      });
    }

    return res.status(500).json({
      error: "Errore interno del server.",
    });
  }
});

// ====== 404 DI DEFAULT ======
app.use((req, res) => {
  res.status(404).json({ error: "Endpoint non trovato" });
});

// ====== AVVIO SERVER ======
app.listen(PORT, () => {
  console.log(
    `🚀 PerfectSocial AI backend in ascolto su http://localhost:${PORT}`
  );
});
